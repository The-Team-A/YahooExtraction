package com.cummins.stockRecommend;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jsoup.Jsoup;  
import org.jsoup.nodes.*;  
import org.jsoup.select.Elements;

public class StockFetcher {  
	
	/*
	* Returns a Stock Object that contains info about a specified stock.
	* @param 	symbol the company's stock symbol
	* @return 	a stock object containing info about the company's stock
	* @see Stock
	*/
	static Stock getStock(String symbol) {  
		String freeFloatMarketCap;
		String change;
		String deliveryQuantity;
		String quantityTraded;
		String open;
		String low52;
		String securityVar;
		String priceBandUpper;
		String totalTradedValue;
		String faceValue;
		String previousClose;
		String varMargin;
		String lastPrice;
		String pChange;
		String averagePrice;
		String priceBandLower;
		String high52;
		String closePrice;
		String totalSellQuantity;
		String dayHigh;
		String applicableMargin;
		String dayLow;
		String deliveryToTradedQuaantity;
		String totalTradedVolume;
		String eps;
		
		
		
		String exchange=new String();
		try { 
	
			// Retrieve CSV File
			URL yahoo = new URL("http://finance.yahoo.com/d/quotes.csv?s="+symbol+".NS&f=e");
			Document doc = Jsoup.connect("https://www.nseindia.com/live_market/dynaContent/live_watch/get_quote/ajaxGetQuoteJSON.jsp?symbol="+symbol).get();
			URLConnection connection = yahoo.openConnection(); 
			InputStreamReader is = new InputStreamReader(connection.getInputStream());
			BufferedReader br = new BufferedReader(is);  
			
			
			 eps = br.readLine();
		//Only split on commas that aren't in quotes
			
			Element body1=doc.body();
			String line=body1.toString();
			System.out.println(line);
			
			String[] stockInfo;
			String[] tempStockInfo1;
			stockInfo = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
			
			int i=0;
			String[] stockInfo1 = new String[stockInfo.length];
			                               
			while(i<stockInfo.length)
			{
				//System.out.println(stockInfo[i]);
				String line1=stockInfo[i];
				tempStockInfo1=line1.split(":");
				stockInfo1[i]=tempStockInfo1[1];
				i++;
			}
			/*while( j<stockInfo1.length)
			{
				System.out.println(stockInfo1[j]);
				j++;
			}*/
			freeFloatMarketCap=stockInfo1[5];
		    change=stockInfo1[7];
			deliveryQuantity=stockInfo1[14];
		    quantityTraded=stockInfo1[17];
		    open=stockInfo1[21];
			low52=stockInfo1[22];
			securityVar=stockInfo1[23];
			priceBandUpper=stockInfo1[25];
			totalTradedValue=stockInfo1[26];
			faceValue=stockInfo1[27];
			previousClose=stockInfo1[29];
			varMargin=stockInfo1[31];
			lastPrice=stockInfo1[32];
			pChange=stockInfo1[33];
			averagePrice=stockInfo1[36];
			priceBandLower=stockInfo1[41];
			high52=stockInfo1[43];
			closePrice=stockInfo1[46];
			totalSellQuantity=stockInfo1[50];
			dayHigh=stockInfo1[51];
			applicableMargin=stockInfo1[63];
			dayLow=stockInfo1[67];
			deliveryToTradedQuaantity=stockInfo1[68];
			totalTradedVolume=stockInfo1[69];
		
		} catch (IOException e) {
			Logger log = Logger.getLogger(StockFetcher.class.getName()); 
			log.log(Level.SEVERE, e.toString(), e);
			return null;
		}
		catch(NullPointerException se)
		{
			se.printStackTrace();
		}
		
		//return new Stock(sym, price, volume, pe, eps, week52low, week52high, daylow, dayhigh, movingav50day, marketcap, name,currency, shortRatio,previousClose,open,exchange);
		return null;
	}
}











